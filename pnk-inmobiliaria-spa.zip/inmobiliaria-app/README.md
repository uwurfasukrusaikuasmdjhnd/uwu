# PNK Inmobiliaria — Catálogo de Propiedades (SPA en React)

SPA desarrollada en **React + Vite + React-Bootstrap + SweetAlert2**, siguiendo la misma
arquitectura de servicios / rutas / componentes usada en las guías del curso (Login,
rutas protegidas y CRUD de usuarios). Consume un catálogo de propiedades inmobiliarias
desde un backend PHP conectado a una base de datos MySQL llamada **PNK**.

## 1. Identidad visual

Paleta "casa de remates de lujo": maderas nobles, cuero y café tostado, con un acento
"oro viejo" que actúa como sello de marca (precio en cinta dorada sobre cada foto,
divisores ornamentales). Tipografía display **Fraunces** (editorial, con carácter) +
texto **Inter** (limpia y legible). Todo el sistema de color vive en variables CSS en
`src/index.css` (`--espresso`, `--cacao`, `--caramelo`, `--oro`, `--lino`, `--crema`),
por lo que puedes ajustar tonos sin tocar los componentes.

## 2. Estructura del proyecto

```
src/
├── components/
│   ├── Header.jsx              # Hero + buscador en tiempo real
│   ├── PropertyCard.jsx        # Card de Bootstrap: foto, título, ubicación, precio
│   ├── PropertyGrid.jsx        # Grilla responsiva + estados de carga/vacío
│   ├── PropertyDetailModal.jsx # Modal con carousel, descripción e íconos
│   └── PropertyFormModal.jsx   # Modal de creación/edición
├── services/
│   └── propertyService.js      # fetch al backend PHP (GET/POST/PUT/DELETE)
├── data/
│   └── mockProperties.js       # Datos de respaldo si el backend no responde
├── utils/format.js             # Formateo de moneda y normalización de imágenes
├── App.jsx                     # Orquesta carga, búsqueda, CRUD y modales
└── index.css                   # Tokens de color/tipografía e identidad visual

api-php-example/                # Backend PHP de referencia para la BD "PNK"
├── db.php                      # Conexión PDO (host/usuario/clave de PNK)
├── propiedades.php             # Endpoint GET/POST/PUT/DELETE
└── schema.sql                  # Tabla "propiedades" + datos de ejemplo
```

## 3. Cómo correr el proyecto en desarrollo

```bash
npm install
cp .env.example .env        # y ajusta VITE_API_URL a tu endpoint PHP real
npm run dev
```

La app queda disponible en `http://localhost:5173`.

## 4. Base de datos y backend (PNK)

- **Base de datos:** `PNK`
- **Usuario:** `penka`
- **Contraseña:** `Colocolo123#`

Estas credenciales ya están escritas en `api-php-example/db.php`. Si MySQL corre en la
misma instancia que PHP, deja `DB_HOST = "localhost"`.

Las columnas de la tabla `propiedades` (ver `schema.sql`) usan los **mismos nombres**
que envía el front-end — `title`, `location`, `price`, `surface_m2`, `bedrooms`,
`bathrooms`, `parking`, `pool`, `year_built`, `description`, `images` — así que el PHP
no necesita traducir nombres de campo.

En `.env`, define `VITE_API_URL` apuntando a tu endpoint real, por ejemplo:

```
VITE_API_URL=http://54.160.151.174/api/propiedades.php
```

Mientras el backend no esté disponible, la SPA sigue funcionando mostrando datos de
demostración (`src/data/mockProperties.js`) y te avisa con un banner en la parte
superior del catálogo — así nunca tendrás la pantalla en blanco durante el desarrollo.

## 5. Verificar que el backend persiste de verdad (checklist de depuración)

Si el front-end "guarda" pero al recargar la propiedad desaparece, es porque el PHP no
está escribiendo en MySQL. Sigue estos pasos en tu instancia AWS:

1. **Revisa que la tabla exista con las columnas correctas:**
   ```sql
   USE PNK;
   DESCRIBE propiedades;
   ```
   Debe incluir `title`, `location`, `price`, `bedrooms`, `bathrooms`, `surface_m2`,
   `parking`, `pool`, `year_built`, `description`, `images`. Si no existe, importa
   `api-php-example/schema.sql`.

2. **Prueba el endpoint directamente con `curl`** (sin pasar por el front-end):
   ```bash
   curl -X POST http://54.160.151.174/api/propiedades.php \
     -H "Content-Type: application/json" \
     -d '{"title":"Casa prueba","location":"Coquimbo","price":100000,"bedrooms":3,"bathrooms":2}'
   ```
   Debe responder `{"ok":true,"data":{...}}`. Si responde un error de conexión, revisa
   las credenciales en `db.php`; si responde HTML/blanco, revisa el log de errores de
   PHP (`/var/log/apache2/error.log` o `php -l propiedades.php` para errores de sintaxis).

3. **Confirma en MySQL que el registro quedó guardado:**
   ```sql
   SELECT * FROM propiedades ORDER BY id DESC LIMIT 5;
   ```
   Si aparece "Casa prueba", el `POST` ya está persistiendo correctamente.

4. **Repite la prueba con `PUT` y `DELETE`** usando el `id` que te devolvió el `POST`:
   ```bash
   curl -X PUT  "http://54.160.151.174/api/propiedades.php?id=ID" -H "Content-Type: application/json" -d '{"title":"Casa editada","location":"Coquimbo","price":120000,"bedrooms":3,"bathrooms":2}'
   curl -X DELETE "http://54.160.151.174/api/propiedades.php?id=ID"
   ```

> Nota: actualmente el front-end (`src/App.jsx`) actualiza el estado de React al
> instante y, en paralelo, intenta sincronizar con el backend. Si el `POST/PUT/DELETE`
> falla, el cambio se ve en pantalla pero no sobrevive a un refresh — exactamente el
> síntoma que el checklist anterior ayuda a diagnosticar.

## 6. Despliegue en AWS (instancia Ubuntu Server)

1. **Compila la app:**
   ```bash
   npm run build
   ```
   Esto genera la carpeta `dist/` con los archivos estáticos listos para producción.
2. **En la instancia Ubuntu Server**, instala Nginx (o Apache), PHP y MySQL:
   ```bash
   sudo apt update
   sudo apt install nginx php php-mysql mysql-server -y
   ```
3. Copia el contenido de `dist/` a `/var/www/html/` (el front-end React) y los archivos
   de `api-php-example/` a una subcarpeta, por ejemplo `/var/www/html/api/`.
4. Crea la base de datos y el usuario, luego importa el esquema:
   ```sql
   CREATE DATABASE IF NOT EXISTS PNK CHARACTER SET utf8mb4;
   CREATE USER IF NOT EXISTS 'penka'@'localhost' IDENTIFIED BY 'Colocolo123#';
   GRANT ALL PRIVILEGES ON PNK.* TO 'penka'@'localhost';
   FLUSH PRIVILEGES;
   ```
   ```bash
   mysql -u penka -p PNK < api-php-example/schema.sql
   ```
5. Actualiza `VITE_API_URL` en `.env` con la IP pública o dominio de la instancia antes
   de volver a compilar (`npm run build`), o sirve el front-end y el backend bajo el
   mismo dominio para evitar configurar CORS.
6. Abre el puerto 80 (y 443 si usas HTTPS) en el Security Group de la instancia AWS.

> **Nota de seguridad:** la contraseña `Colocolo123#` queda en texto plano en
> `db.php`. Está bien para un laboratorio académico, pero si subes este repositorio a
> GitHub público, considera mover las credenciales a variables de entorno del servidor
> en lugar de dejarlas comiteadas.

## 7. Edición y eliminación (3.5 / 3.6)

Por defecto, **editar y eliminar actualizan el estado de React de inmediato** (para que
la interfaz responda al instante, tal como pide la pauta), y además intentan sincronizar
el cambio contra tu backend (`PUT` / `DELETE` en `propertyService.js`). Si el backend
falla, el intento se registra en la consola del navegador sin bloquear la experiencia,
pero el cambio no sobrevivirá a un refresh hasta que el endpoint persista correctamente
(ver checklist de la sección 5).

## 8. Checklist según la pauta de evaluación

- [x] **3.1** Carga de datos desde backend con `useEffect` + `fetch` (`propertyService.js`).
- [x] **3.2** Catálogo con Cards de Bootstrap: título, foto, ubicación y precio; clic abre el modal.
- [x] **3.3** Modal de detalle con carousel de Bootstrap, descripción e íconos (superficie,
      dormitorios, baños, piscina condicional, estacionamientos, año de construcción).
- [x] **3.4** Buscador en tiempo real sobre los datos cargados, sin recargar la página.
- [x] **3.5** Edición de propiedades reflejada al instante en la interfaz (+ sincronización con backend).
- [x] **3.6** Eliminación con confirmación previa vía SweetAlert2 (+ sincronización con backend).
- [x] **3.7** Interfaz responsiva, con identidad visual propia (paleta café/madera, tipografía
      editorial, micro-interacciones de hover).
