<?php
// propiedades.php — Endpoint de PNK Inmobiliaria para el catálogo de propiedades.
//
// Las columnas de la tabla usan los MISMOS nombres que el front-end envía/espera
// (title, location, price, surface_m2, bedrooms, bathrooms, parking, pool,
// year_built, description, images), así que no se necesita ninguna traducción
// entre el JSON y la base de datos. Ver schema.sql para crear la tabla.
//
// Respuestas:
//   GET    -> { "ok": true, "data": [ {...}, {...} ] }
//   POST   -> { "ok": true, "data": { ...propiedad creada... } }
//   PUT    -> { "ok": true, "data": { ...propiedad actualizada... } }
//   DELETE -> { "ok": true, "message": "Propiedad eliminada" }
//   error  -> { "ok": false, "message": "..." }  (con código HTTP != 2xx)

header("Content-Type: application/json; charset=utf-8");

// CORS: necesario porque React (Vite) y PHP corren en orígenes distintos.
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

require_once __DIR__ . "/db.php";

$method = $_SERVER["REQUEST_METHOD"];
$id = isset($_GET["id"]) ? (int) $_GET["id"] : null;

// Convierte una fila cruda de MySQL a los tipos correctos para el front-end.
function mapRow($row)
{
    return [
        "id" => (int) $row["id"],
        "title" => $row["title"],
        "location" => $row["location"],
        "price" => (float) $row["price"],
        "surface_m2" => (int) $row["surface_m2"],
        "bedrooms" => (int) $row["bedrooms"],
        "bathrooms" => (int) $row["bathrooms"],
        "parking" => (int) $row["parking"],
        "pool" => (bool) $row["pool"],
        "year_built" => $row["year_built"] !== null ? (int) $row["year_built"] : null,
        "description" => $row["description"],
        "images" => $row["images"] ? explode(",", $row["images"]) : [],
    ];
}

// Lee y decodifica el body JSON. Si viene vacío o mal formado, devuelve [].
function readJsonBody()
{
    $raw = file_get_contents("php://input");
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

try {
    switch ($method) {
        case "GET":
            $stmt = $pdo->query("SELECT * FROM propiedades ORDER BY id DESC");
            $rows = $stmt->fetchAll();
            echo json_encode(["ok" => true, "data" => array_map("mapRow", $rows)]);
            break;

        case "POST":
            $input = readJsonBody();

            // Validación mínima: sin estos tres campos no tiene sentido crear el registro.
            if (empty($input["title"]) || empty($input["location"]) || !isset($input["price"])) {
                http_response_code(400);
                echo json_encode([
                    "ok" => false,
                    "message" => "Los campos title, location y price son obligatorios",
                ]);
                break;
            }

            $stmt = $pdo->prepare(
                "INSERT INTO propiedades
                    (title, location, price, surface_m2, bedrooms, bathrooms, parking, pool, year_built, description, images)
                 VALUES
                    (:title, :location, :price, :surface_m2, :bedrooms, :bathrooms, :parking, :pool, :year_built, :description, :images)"
            );

            $stmt->execute([
                ":title" => $input["title"],
                ":location" => $input["location"],
                ":price" => $input["price"],
                ":surface_m2" => $input["surface_m2"] ?? 0,
                ":bedrooms" => $input["bedrooms"] ?? 0,
                ":bathrooms" => $input["bathrooms"] ?? 0,
                ":parking" => $input["parking"] ?? 0,
                ":pool" => !empty($input["pool"]) ? 1 : 0,
                ":year_built" => $input["year_built"] ?? null,
                ":description" => $input["description"] ?? "",
                ":images" => isset($input["images"])
                    ? (is_array($input["images"]) ? implode(",", $input["images"]) : $input["images"])
                    : "",
            ]);

            $newId = (int) $pdo->lastInsertId();
            $row = $pdo->query("SELECT * FROM propiedades WHERE id = {$newId}")->fetch();

            http_response_code(201);
            echo json_encode(["ok" => true, "data" => mapRow($row)]);
            break;

        case "PUT":
            if (!$id) {
                http_response_code(400);
                echo json_encode(["ok" => false, "message" => "Falta el parámetro ?id= en la URL"]);
                break;
            }

            $existing = $pdo->prepare("SELECT id FROM propiedades WHERE id = :id");
            $existing->execute([":id" => $id]);
            if (!$existing->fetch()) {
                http_response_code(404);
                echo json_encode(["ok" => false, "message" => "No existe una propiedad con id {$id}"]);
                break;
            }

            $input = readJsonBody();

            $stmt = $pdo->prepare(
                "UPDATE propiedades SET
                    title = :title,
                    location = :location,
                    price = :price,
                    surface_m2 = :surface_m2,
                    bedrooms = :bedrooms,
                    bathrooms = :bathrooms,
                    parking = :parking,
                    pool = :pool,
                    year_built = :year_built,
                    description = :description,
                    images = :images
                 WHERE id = :id"
            );

            $stmt->execute([
                ":title" => $input["title"] ?? "",
                ":location" => $input["location"] ?? "",
                ":price" => $input["price"] ?? 0,
                ":surface_m2" => $input["surface_m2"] ?? 0,
                ":bedrooms" => $input["bedrooms"] ?? 0,
                ":bathrooms" => $input["bathrooms"] ?? 0,
                ":parking" => $input["parking"] ?? 0,
                ":pool" => !empty($input["pool"]) ? 1 : 0,
                ":year_built" => $input["year_built"] ?? null,
                ":description" => $input["description"] ?? "",
                ":images" => isset($input["images"])
                    ? (is_array($input["images"]) ? implode(",", $input["images"]) : $input["images"])
                    : "",
                ":id" => $id,
            ]);

            $row = $pdo->query("SELECT * FROM propiedades WHERE id = {$id}")->fetch();
            echo json_encode(["ok" => true, "data" => mapRow($row)]);
            break;

        case "DELETE":
            if (!$id) {
                http_response_code(400);
                echo json_encode(["ok" => false, "message" => "Falta el parámetro ?id= en la URL"]);
                break;
            }

            $stmt = $pdo->prepare("DELETE FROM propiedades WHERE id = :id");
            $stmt->execute([":id" => $id]);

            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(["ok" => false, "message" => "No existe una propiedad con id {$id}"]);
                break;
            }

            echo json_encode(["ok" => true, "message" => "Propiedad eliminada"]);
            break;

        default:
            http_response_code(405);
            echo json_encode(["ok" => false, "message" => "Método no permitido"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "ok" => false,
        "message" => "Error de base de datos: " . $e->getMessage(),
    ]);
}
