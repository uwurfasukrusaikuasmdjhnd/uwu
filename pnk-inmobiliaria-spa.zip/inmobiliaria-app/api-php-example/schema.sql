-- schema.sql — Estructura de referencia para PNK Inmobiliaria.
-- Columnas en inglés para que coincidan 1 a 1 con lo que envía/espera el front-end
-- (sin necesidad de traducir nombres de campo en el PHP).

-- 1) Si la base de datos y el usuario "penka" todavía no existen, créalos
--    una vez conectado a MySQL como root (ajusta el host '%' si te conectas
--    desde otra máquina y no solo desde localhost):
--
-- CREATE DATABASE IF NOT EXISTS PNK CHARACTER SET utf8mb4;
-- CREATE USER IF NOT EXISTS 'penka'@'localhost' IDENTIFIED BY 'Colocolo123#';
-- GRANT ALL PRIVILEGES ON PNK.* TO 'penka'@'localhost';
-- FLUSH PRIVILEGES;

USE PNK;

CREATE TABLE IF NOT EXISTS propiedades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    location VARCHAR(150) NOT NULL,
    price DECIMAL(14,0) NOT NULL DEFAULT 0,
    surface_m2 INT NOT NULL DEFAULT 0,
    bedrooms INT NOT NULL DEFAULT 0,
    bathrooms INT NOT NULL DEFAULT 0,
    parking INT NOT NULL DEFAULT 0,
    pool TINYINT(1) NOT NULL DEFAULT 0,
    year_built INT NULL,
    description TEXT,
    images TEXT COMMENT 'URLs separadas por coma',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO propiedades
    (title, location, price, surface_m2, bedrooms, bathrooms, parking, pool, year_built, description, images)
VALUES
    ("Casa Los Robles", "Vitacura, Santiago", 685000000, 320, 4, 3, 2, 1, 2019,
     "Residencia contemporánea de dos pisos con terraza, jardines maduros y piscina.",
     "https://images.unsplash.com/photo-1564013799919-ab600027ffc6,https://images.unsplash.com/photo-1600596542815-ffad4c1539a9"),
    ("Penthouse Mirador del Parque", "Las Condes, Santiago", 540000000, 210, 3, 3, 2, 0, 2021,
     "Penthouse con terraza panorámica y vista a la cordillera.",
     "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688");
