<?php
// db.php — Conexión a la base de datos PNK Inmobiliaria.
// Si tu PHP corre en la MISMA instancia EC2 que MySQL, deja DB_HOST en "localhost".
// Si MySQL está en otro servidor (otra instancia/RDS), reemplaza "localhost" por esa IP.

$DB_HOST = "localhost";
$DB_NAME = "PNK";
$DB_USER = "penka";
$DB_PASS = "Colocolo123#";

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode([
        "ok" => false,
        "message" => "Error de conexión a la base de datos: " . $e->getMessage(),
    ]);
    exit;
}
